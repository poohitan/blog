﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoohMathParser
{
    /// <summary>
    /// Class for storing mathematical expressions. 
    /// </summary>
    public class MathExpression
    {
        private string expression;
        private List<Token> tokens;
        private List<Token> reversePolishNotation;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="expression">String expression to parse</param>
        public MathExpression(string expression)
        {
            this.expression = PrepareString(expression);
            tokens = GetTokens(this.expression);
            reversePolishNotation = ConvertToReversePolishNotation(tokens);
        }

        #region Dictionaries with operators, functions etc. and their delegates

        private Dictionary<string, Func<double, double, double>> operators = 
            new Dictionary<string, Func<double, double, double>>
            {
                { "+", (operand1, operand2) => Plus(operand1, operand2) },
                { "-", (operand1, operand2) => Minus(operand1, operand2) },
                { "*", (operand1, operand2) => Multiplication(operand1, operand2) },
                { "/", (operand1, operand2) => Division(operand1, operand2) },
                { "^", (operand1, operand2) => Pow(operand1, operand2) },
                { "(", null },
                { ")", null },
            };

        private Dictionary<string, Func<double, double>> functions = new Dictionary<string, Func<double, double>>
            {
                { "sin", (operand) => Sin(operand) },
                { "cos", (operand) => Cos(operand) },
                { "tg", (operand) => Tg(operand) },
                { "ctg", (operand) => Ctg(operand) },
                { "arcsin", (operand) => Arcsin(operand) },
                { "arccos", (operand) => Arccos(operand) },
                { "arctg", (operand) => Arctg(operand) },
                { "arcctg", (operand) => Arcctg(operand) },
                { "sinh", (operand) => Sinh(operand) },
                { "cosh", (operand) => Cosh(operand) },
                { "tgh", (operand) => Tgh(operand) },
                { "ctgh", (operand) => Ctgh(operand) },
                { "ln", (operand) => Ln(operand) },
                { "lg", (operand) => Lg(operand) },
                { "sqrt", (operand) => Sqrt(operand) },
                { "abs", (operand) => Abs(operand) },
                { "sign", (operand) => Sign(operand) },
            };

        private Dictionary<string, double> constants = new Dictionary<string, double>
            {
                { "e", Math.E },
                { "pi", Math.PI },
            };

        private List<char> variables = new List<char>()
            {
                'x', 'y', 'z'
            };

        #endregion

        #region Operators implementation

        private static double Plus(double operand1, double operand2)
        {
            return operand1 + operand2;
        }
        private static double Minus(double operand1, double operand2)
        {
            return operand2 - operand1;
        }
        private static double Multiplication(double operand1, double operand2)
        {
            return operand1 * operand2;
        }
        private static double Division(double operand1, double operand2)
        {
            return operand2 / operand1;
        }
        private static double Pow(double operand1, double operand2)
        {
            return Math.Pow(operand2, operand1);
        }

        #endregion

        #region Functions implementation

        private static double Sin(double operand)
        {
            return Math.Sin(operand);
        }
        private static double Cos(double operand)
        {
            return Math.Cos(operand);
        }
        private static double Tg(double operand)
        {
            return Math.Tan(operand);
        }
        private static double Ctg(double operand)
        {
            return 1 / Math.Tan(operand);
        }
        private static double Arcsin(double operand)
        {
            return Math.Asin(operand);
        }
        private static double Arccos(double operand)
        {
            return Math.Acos(operand);
        }
        private static double Arctg(double operand)
        {
            return Math.Atan(operand);
        }
        private static double Arcctg(double operand)
        {
            return 1 / Math.Atan(operand);
        }
        private static double Sinh(double operand)
        {
            return Math.Sinh(operand);
        }
        private static double Cosh(double operand)
        {
            return Math.Cosh(operand);
        }
        private static double Tgh(double operand)
        {
            return Math.Tanh(operand);
        } 
        private static double Ctgh(double operand)
        {
            return 1 / Math.Tanh(operand);
        }      
        private static double Ln(double operand)
        {
            return Math.Log(operand);
        }
        private static double Lg(double operand)
        {
            return Math.Log10(operand);
        }
        private static double Sqrt(double operand)
        {
            return Math.Sqrt(operand);
        }
        private static double Abs(double operand)
        {
            return Math.Abs(operand);
        }
        private static double Sign(double operand)
        {
            return Math.Sign(operand);
        }

        #endregion

        #region Methods for string preparation, splitting string to tokens and so on.

        /// <summary>
        /// Preparing string for it's further convertion to the sequence of tokens. This method is deleting whitespaces etc.
        /// </summary>
        /// <param name="expression">String expression to prepare</param>
        /// <returns>String prepared for converting to the sequence of tokens</returns>
        private string PrepareString(string expression)
        {
            //Deleting all the spaces from the string
            expression = expression.Replace(" ", string.Empty);

            //Searching for unary minus operators and replacing them with "0-"
            //for (int i = 0; i < expression.Length; ++i)
            //{
            //    if (expression[i] == '-')
            //    {
            //        if (i > 0)
            //        {
            //            double result;
            //            double.TryParse(expression[i - 1].ToString(), out result);
            //            if (result == 0)
            //            {
            //               expression = expression.Insert(i, "0");
            //               ++i;
            //            }
            //        }
            //        else
            //        {
            //            expression = expression.Insert(i, "0");
            //            ++i;
            //        }
            //    }
            //}

            return expression;
        }

        /// <summary>
        /// Parses a string of characters and converts it to sequence of tokens.
        /// </summary>
        /// <param name="expression">String expression to parse</param>
        /// <returns>Sequence of tokens</returns>
        private List<Token> GetTokens(string expression)
        {
            List<Token> tokens = new List<Token>();

            bool isError;
            for (int i = 0; i < expression.Length; ++i)
            {
                isError = true;
                string number = "";
                double num;
                while ((double.TryParse(expression[i].ToString(), out num) || expression[i] == '.' || expression[i] == ','))
                {
                    if (expression[i] == ',' || expression[i] == '.')
                    {
                        number += ",";
                    }
                    else
                    {
                        number += num.ToString();
                    }

                    if (i < expression.Length - 1)
                    {
                        ++i;
                    }
                    else break;
                }
                if (number != "")
                {
                    Token t = new Token(number, TokenType.Number);
                    tokens.Add(t);
                    isError = false;
                    number = "";
                }

                foreach (string s in operators.Keys)
                {
                    if (expression[i].ToString() == s)
                    {
                        Token t = new Token(expression[i].ToString(), TokenType.Operator);
                        tokens.Add(t);
                        isError = false;
                    }
                }

                foreach (string s in functions.Keys)
                {
                    string function = "";

                    int k = i;
                    for (int j = 0; j < s.Length; ++j)
                    {
                        if (s[j] == expression[k])
                        {
                            function += expression[k];
                        }
                        if (k < expression.Length - 1)
                        {
                            ++k;
                        }
                        else break;
                    }
                    if (function == s)
                    {
                        Token t = new Token(function, TokenType.Function);
                        tokens.Add(t);
                        isError = false;
                        i += function.Length - 1;
                    }
                }

                foreach (char c in variables)
                {
                    if (expression[i] == c)
                    {
                        Token t = new Token(expression[i].ToString(), TokenType.Variable);
                        tokens.Add(t);
                        isError = false;
                    }
                }

                foreach (string s in constants.Keys)
                {
                    string constant = "";

                    int k = i;
                    for (int j = 0; j < s.Length; ++j)
                    {
                        if (s[j] == expression[k])
                        {
                            constant += expression[k];
                        }
                        if (k < expression.Length - 1)
                        {
                            ++k;
                        }
                        else break;
                    }
                    if (constant == s)
                    {
                        Token t = new Token(constant, TokenType.Constant);
                        tokens.Add(t);
                        isError = false;
                        i += constant.Length - 1;
                    }
                }

                if (isError)
                {
                    throw new ArgumentException("Bad expression string.");
                }
            }

            return tokens;
        }      

        /// <summary>
        /// Converts sequence of tokens from infix notation to postfix (reverse polish notation). See Shunting-yard algorithm for details.
        /// </summary>
        /// <param name="tokens">Sequence of tokens in infix notation</param>
        /// <returns>Sequence of tokens in reverse polish notation</returns>
        private List<Token> ConvertToReversePolishNotation(List<Token> tokens)
        {
            List<Token> reversePolishNotation = new List<Token>();
            Stack stack = new Stack();

            foreach (Token t in tokens)
            {
                if (t.Type == TokenType.Number || t.Type == TokenType.Variable || t.Type == TokenType.Constant)
                {
                    reversePolishNotation.Add(t);
                }
                else if (t.Type == TokenType.Function)
                {
                    stack.Push(t);
                }
                else if (t.Lexeme == "(")
                {
                    stack.Push(t);
                }
                else if (t.Type == TokenType.Operator && t.Lexeme != ")")
                {
                    if (!stack.Empty())
                    {
                        while (stack.Top().Type == TokenType.Operator && t.Priority <= stack.Top().Priority)
                        {
                            reversePolishNotation.Add(stack.Pop());
                            if (stack.Empty())
                            {
                                break;
                            }
                        }
                        stack.Push(t);
                    }
                    else
                    {
                        stack.Push(t);
                    }
                }
                else if (t.Type == TokenType.Operator && t.Lexeme == ")")
                {
                    if (!stack.Empty())
                    {
                        while (stack.Top().Lexeme != "(")
                        {
                            reversePolishNotation.Add(stack.Pop());
                            if (stack.Empty())
                            {
                                break;
                            }
                        }
                        stack.Pop();
                        if (!stack.Empty())
                        {
                            if (stack.Top().Type == TokenType.Function)
                            {
                                reversePolishNotation.Add(stack.Pop());
                            }
                        }
                    }
                }
            }

            while (!stack.Empty())
            {
                reversePolishNotation.Add(stack.Pop());
            }

            return reversePolishNotation;
        }

        #endregion

        /// <summary>
        /// Calculates value of the expression.
        /// </summary>
        /// <returns>Value of the expression</returns>
        public double Calculate()
        {
            return this.Calculate(0);
        }

        /// <summary>
        /// Calculates value of the expression at specified point.
        /// </summary>
        /// <param name="point">Point to calculate expression at</param>
        /// <returns>Value of the expression at specified point</returns>
        public double Calculate(double point)
        {
            Stack stack = new Stack();

            foreach (Token t in reversePolishNotation)
            {
                if (t.Type == TokenType.Number)
                {
                    stack.Push(t);
                }
                else if (t.Type == TokenType.Operator)
                {
                    double operand1 = double.Parse(stack.Pop().Lexeme);
                    double operand2 = double.Parse(stack.Pop().Lexeme);
                    double smallResult = operators[t.Lexeme](operand1, operand2);
                    stack.Push(new Token(smallResult.ToString(), TokenType.Number));
                }
                else if (t.Type == TokenType.Function)
                {
                    double operand = double.Parse(stack.Pop().Lexeme);
                    double smallResult = functions[t.Lexeme](operand);
                    stack.Push(new Token(smallResult.ToString(), TokenType.Number));
                }
                else if (t.Type == TokenType.Constant)
                {
                    double constant = constants[t.Lexeme];
                    stack.Push(new Token(constant.ToString(), TokenType.Number));
                }
                else if (t.Type == TokenType.Variable)
                {
                    Token smallToken = new Token(point.ToString(), TokenType.Number);
                    stack.Push(smallToken);
                }
                else
                {
                    throw new ArgumentException("Bad expression string.");
                }
            }

            double result = double.Parse(stack.Pop().Lexeme);

            return result;
        }

        /// <summary>
        /// Calculates the first derivative of the expression at specified point.
        /// </summary>
        /// <param name="x0">Point derivative is calculated at</param>
        /// <returns></returns>
        public double Derivative(double x0)
        {
            double result;

            double dx = Math.Pow(10, -10);
            result = (this.Calculate(x0 + dx) - this.Calculate(x0)) / dx;

            return result;
        }

        /// <summary>
        /// Calculates the second derivative of the expression at specified point.
        /// </summary>
        /// <param name="x0">Point derivative is calculated at</param>
        /// <returns></returns>
        public double SecondDerivative(double x0)
        {
            double result;

            double dx = Math.Pow(10, -5);
            result = (2 / Math.Pow(dx, 2)) * ((this.Calculate(x0 + dx)
                + this.Calculate(x0 - dx)) / 2 - this.Calculate(x0));

            return result;
        }

        /// <summary>
        /// Converts expression to string. 
        /// </summary>
        /// <returns>String representation of the expression</returns>
        public override string ToString()
        {
            return expression;
        }
    }
}
