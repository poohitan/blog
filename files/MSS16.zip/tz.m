function tz = tz(t0, te, n)
tz(1) = t0 + 0.1 * (te-t0);
step = (te - tz(1)) / (n-1);
for i = 2 : (n) 
  tz(i) = tz(i - 1) + step
end

end

