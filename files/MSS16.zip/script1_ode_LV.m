t0=0; te=50;
Y0 = [1; 1.5];
p=[0.63 -0.5 -0.1 -0.71 0.8 0.32 0.97 0.02 0.15 0.05 -0.2];
[pn, pv] = pn_pv(p);
tz1 = tz(t0, te, 5);
tz2 = tz(t0, te, 4);

options = odeset('RelTol', 1e-4, 'AbsTol', [1e-5 1e-5]);
[T, Y] = ode15s(@LV_2r4p_F, [t0 te], Y0, options, p);
plot(T, Y(:, 1), '-', T, Y(:, 2), '-.')
legend('y1, prey', 'y2, predator')

%u = u( 2, 11, p, pn, pv)

options = odeset('Jacobian', @LV_2r4p_Jac, 'RelTol', 1e-5, 'AbsTol', 1e-5);
sol = ode15s(@LV_2r4p_F, [t0 te], Y0, options, p); 
   figure
   plot(sol.y(1, :), sol.y(2, :))
   title('solution y1(t), y2(t)')
   xlabel('y1')
   ylabel('y2')
   grid 'on'
   figure
   plot(sol.x, sol.y(1, :))
   title('solution t, y1(t)')
   xlabel('t')
   ylabel('y1')
   grid 'on'
   figure
   plot(sol.x, sol.y(2, :))
   title('solution t, y2(t)')
   xlabel('t')
   ylabel('y2')
   grid 'on'

 %  u = [-0.6108 -0.1906];
   u = [-0.6000 -0.1500];
   sol1 = deval(sol, tz1);
   sol2 = deval(sol, tz2);
   gz1 = sol1(1, :);
   gz2 = sol2(2, :);
   gz1 = gz1 * p(11);
   
   pz = p;

pz(2) = u(1);
pz(11) = u(2);
    
   sol = ode15s(@LV_2r4p_F, [t0 te], Y0, options, pz); 
   sol1 = deval(sol, tz1);
   sol2 = deval(sol, tz2);
   gzopt1 = sol1(1, :);
   gzopt2 = sol2(2, :);
   gzopt1 = gzopt1 * u(2);
   psi = sum((gzopt1 - gz1).^2) + sum((gzopt2 - gz2).^2)
   
  figure
   plot(tz1(:), gzopt1(:), '*', tz1(:),  gz1(:), '*')
   legend('gzopt1', 'gz1');
   grid 'on'
  figure
   plot( tz2(:), gzopt2(:), '*', tz2(:),  gz2(:), '*')
   legend('gzopt2', 'gz2');
   grid 'on'
   
   %6
sol = ode15s(@LV_2r4p_F, [t0 te], Y0, options, p);
ph = [0.01 0.01];
pFD1 = p;
pFD1(2) = p(2) + ph(1);
 
solu1 = ode15s(@LV_2r4p_F, [t0 te], Y0, options, pFD1);
 
pFD2 = p;
pFD2(11) = p(11) + ph(2);
 
solu2 = ode15s(@LV_2r4p_F, [t0 te], Y0, options, pFD2);
 
solu1 = deval(solu1, sol.x);
solu2 = deval(solu2, sol.x);
 
figure
plot(sol.x, (solu1(1, :) - sol.y(1, :)) / ph(1), sol.x, (solu1(2, :) - sol.y(2, :)) / ph(1))
title('solution(FD) t, dy1/du1, dy2/du1')
legend('dy1/du1', 'dy2/du1');
xlabel('t')

figure
plot(sol.x, (solu2(1, :) - sol.y(1, :)) / ph(2), sol.x, (solu2(2, :) - sol.y(2, :)) / ph(2))
title('solution(FD) t, dy1/du2, dy2/du2')
legend('dy1/du2', 'dy2/du2');
xlabel('t')

options1 = optimset('MaxFunEvals', 300, 'Display', 'off');
UminFmCDD = fminsearch(@(u)Func_Psi0(u, t0, te, Y0, tz1, tz2, options, p, sol), u, options1)