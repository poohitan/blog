function [ pn, pv ] = pn_pv( p )

a = 0.5;
for i = 1 : 11 
  pn(i) = p(i) - a*abs(p(i))
  pv(i) = p(i) + a*abs(p(i))
end

end

