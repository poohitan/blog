function psi0=Func_Psi0(u,t0,te,Y0,tz1,tz2,options,p,sol)
   sol1 = deval(sol, tz1);
   sol2 = deval(sol, tz2);
   gz1 = sol1(1, :);
   gz2 = sol2(2, :);
   gz1 = gz1 * p(2);
     
   pz = p;

   pz(2) = u(1);
   pz(11) = u(2);
    
   sol = ode15s(@LV_2r4p_F, [t0 te], Y0, options, pz); 
   sol1 = deval(sol, tz1);
   sol2 = deval(sol, tz2);
   gzopt1 = sol1(1, :);
   gzopt2 = sol2(2, :);
   gzopt1 = gzopt1 * u(1);
   psi0 = sum((gzopt1 - gz1).^2) + sum((gzopt2 - gz2).^2);
end