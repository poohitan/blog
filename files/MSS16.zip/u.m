function u = u( k1, k2, p, pn, pv)
 
u(1) = rand()*(pv(k1) - pn(k1)) + pn(k1);
if(u(1) == p(k1))
    u(1) = u(1) + 0.0001;
end
u(2) = rand()*(pv(k2) - pn(k2)) + pn(k2);
if(u(2) == p(k2))
    u(2) = u(2) + 0.0001;
end
end